# 🎓 Ganit Guru — Class 6 Virtual AI Teacher (Maths • Science • English)

A **talking, human-like AI teacher** for Class 6 — now **multi-subject**, with a **photoreal 3D
avatar** and **fully-offline voice**. It follows this exact flow:

1. 📱 **Student opens the app** → avatar greets them.
2. 🎯 **Picks a SUBJECT** (Maths / Science / English) → then a topic.
3. 📤 **Uploads the chapter** (JPG / PNG / PDF) → app reads it (OCR / PDF text).
4. 🧑‍🏫 **Avatar teaches** the topic, one concept at a time, from the uploaded chapter.
5. ❓ **Avatar asks questions** to check understanding.
6. 🔍 **Checks understanding** — re-teaches weak points gently.
7. 📝 **Gives homework** + a progress card.

## ✨ New in this version
- **📚 Three subjects** — Maths 🧮, Science 🔬, English 📖 (each with its own NCERT topics
  and a subject-tuned teaching style). Edit in `backend/persona.js` + `frontend/src/App.jsx`.
- **🖼️ Photoreal 3D avatar** — `components/Avatar3D.jsx` renders a **Ready Player Me** `.glb`
  with **three.js**; lips move via ARKit viseme blendshapes driven by real audio amplitude,
  with auto-blink. Toggle **3D ⇄ SVG** in the top bar. Replace `DEFAULT_MODEL` with your own
  avatar URL from https://readyplayer.me.
- **🗣️ Fully-offline voice** — `backend/voice.js` exposes `/api/tts` (**Piper**) and `/api/stt`
  (**whisper.cpp**). The frontend uses them when available and **auto-falls back** to the
  browser Web Speech API, so it always works.

### Enabling offline voice (optional)
```bash
# Piper TTS  → https://github.com/rhasspy/piper  (download a voice .onnx)
# whisper.cpp → https://github.com/ggerganov/whisper.cpp (download ggml-base.en.bin)
PIPER_BIN=/path/piper PIPER_VOICE=/path/en_US-amy-medium.onnx \
WHISPER_BIN=/path/whisper/main WHISPER_MODEL=/path/ggml-base.en.bin \
npm start
```
If these aren't set, the app quietly uses the browser's built-in voice instead.

Everything runs **locally in the browser** (voice, OCR, avatar). The AI "brain" can run
**fully offline** (Ollama), via a **cloud API**, or a built-in **rule-based fallback** so it
always works even with no model configured.

---

## 🗂️ Project structure

```
ganit-guru/
├── backend/                # Node.js "brain" gateway
│   ├── server.js           # /api/teach endpoint (Ollama / OpenAI / fallback)
│   ├── persona.js          # Ganit Guru teaching persona (system prompt)
│   └── package.json
└── frontend/               # ReactJS + Vite app
    ├── index.html
    ├── vite.config.js
    ├── package.json
    └── src/
        ├── App.jsx                 # the 7-step flow
        ├── main.jsx
        ├── styles.css
        ├── components/Avatar.jsx   # SVG talking face (mouth lip-syncs to voice)
        ├── hooks/useSpeech.js      # TTS (speak) + STT (listen), browser Web Speech API
        └── lib/
            ├── readChapter.js      # OCR (tesseract.js) + PDF (pdfjs) reader
            └── api.js              # calls the backend brain
```

---

## ▶️ How to run (local)

### 1) Start the backend (the "brain")
```bash
cd backend
npm install
npm start          # → http://localhost:5000
```
By default it uses the **rule-based fallback** (works with no setup).

**Optional — make it smart:**
- **Fully offline with Ollama:**
  ```bash
  # install Ollama, then:
  ollama pull llama3.1
  USE_OLLAMA=true OLLAMA_MODEL=llama3.1 npm start
  ```
- **Cloud (OpenAI-compatible):**
  ```bash
  OPENAI_API_KEY=sk-xxxx npm start
  ```

### 2) Start the frontend
```bash
cd frontend
npm install
npm run dev        # → http://localhost:5173
```
Open the browser, click **Start Class**, pick a topic, upload a chapter photo/PDF, and learn!

> 💡 Use **Chrome or Edge** for the best Web Speech (voice in/out) support.
> Allow **microphone** access when prompted.

---

## 🧠 How each step maps to the code

| Step | Where |
|------|-------|
| Greet + ask subject | `App.jsx` → `start()` |
| Pick topic | `App.jsx` → `chooseTopic()` |
| Upload + read chapter | `lib/readChapter.js` (OCR + PDF) |
| Teach | backend `phase: "teach"` |
| Ask questions | backend `phase: "quiz"` |
| Check understanding | backend `phase: "check"` |
| Homework + progress | backend `phase: "homework"` |
| Talking face | `components/Avatar.jsx` + `hooks/useSpeech.js` |

---

## 🔧 Make it your own
- **Change the teacher's personality/rules** → edit `backend/persona.js`.
- **Add subjects** (Science, English) → extend `TOPICS` in `App.jsx` and persona.
- **Photoreal avatar** → swap the SVG in `Avatar.jsx` for a **Ready Player Me + three.js**
  model, or an **Azure TTS Avatar** / **D-ID** stream.
- **Better offline voice** → replace Web Speech with **Piper TTS** + **Whisper** (STT).

---

Built for exam prep, one friendly lesson at a time. 🎉
