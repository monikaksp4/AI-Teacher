// Ganit Guru — Class 6 AI Teacher (main app) — MULTI-SUBJECT + 3D avatar
// Flow:
//   1. Open app  -> avatar greets
//   2. Pick SUBJECT (Maths / Science / English)
//   3. Pick TOPIC + upload chapter (JPG/PDF)  -> OCR/PDF read
//   4. Avatar teaches -> 5. asks questions -> 6. checks -> 7. homework + progress
import { useEffect, useRef, useState } from "react";
import Avatar from "./components/Avatar";       // lightweight SVG face
import Avatar3D from "./components/Avatar3D";    // photoreal 3D (Ready Player Me)
import { useSpeech } from "./hooks/useSpeech";
import { readChapter } from "./lib/readChapter";
import { askTeacher } from "./lib/api";
import "./styles.css";

// Per-subject Class 6 (NCERT) topics
const SUBJECTS = {
  Maths: {
    icon: "🧮",
    topics: ["Knowing Our Numbers", "Whole Numbers", "Playing with Numbers",
      "Basic Geometrical Ideas", "Integers", "Fractions", "Decimals",
      "Data Handling", "Mensuration", "Algebra", "Ratio and Proportion"],
  },
  Science: {
    icon: "🔬",
    topics: ["Food: Where Does It Come From", "Components of Food", "Fibre to Fabric",
      "Sorting Materials", "Separation of Substances", "Getting to Know Plants",
      "Body Movements", "Living Organisms & Habitat", "Motion & Measurement",
      "Light, Shadows & Reflections", "Electricity & Circuits", "Fun with Magnets",
      "Water", "Air Around Us", "Garbage In, Garbage Out"],
  },
  English: {
    icon: "📖",
    topics: ["Nouns", "Pronouns", "Verbs & Tenses", "Adjectives", "Prepositions",
      "Articles", "Reading Comprehension", "Vocabulary & Spelling",
      "Sentence Making", "Paragraph Writing", "Letter Writing"],
  },
};

const STAGE = {
  WELCOME: "welcome",
  SUBJECT: "subject",
  PICK: "pick",
  UPLOAD: "upload",
  TEACH: "teach",
  QUIZ: "quiz",
  HOMEWORK: "homework",
};

export default function App() {
  const [stage, setStage] = useState(STAGE.WELCOME);
  const [subject, setSubject] = useState("Maths");
  const [topic, setTopic] = useState("");
  const [chapterText, setChapterText] = useState("");
  const [uploadPct, setUploadPct] = useState(0);
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [mouth, setMouth] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [askedCount, setAskedCount] = useState(0);
  const [use3D, setUse3D] = useState(true); // toggle 3D <-> SVG avatar
  const chatEndRef = useRef(null);

  const { speak, stopSpeaking, listen, speaking, listening } = useSpeech({ onMouth: setMouth });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function teacherSay(text) {
    setMessages((m) => [...m, { role: "assistant", content: text }]);
    await speak(text);
  }
  function studentSay(text) {
    setMessages((m) => [...m, { role: "user", content: text }]);
  }
  const hist = () => messages.map(({ role, content }) => ({ role, content }));

  // STEP 1 -> 2
  async function start() {
    setStage(STAGE.SUBJECT);
    await teacherSay("Namaste! 🙏 I'm your Class 6 teacher. Which subject shall we learn today — Maths, Science, or English?");
  }

  // STEP 2 -> 3
  async function chooseSubject(s) {
    setSubject(s);
    setStage(STAGE.PICK);
    await teacherSay(`Wonderful — ${s} ${SUBJECTS[s].icon} it is! Pick today's topic below.`);
  }

  // STEP 3a
  async function chooseTopic(t) {
    setTopic(t);
    setStage(STAGE.UPLOAD);
    await teacherSay(`Great choice — ${t}! 😊 Please upload your chapter as a JPG, PNG, or PDF so I teach exactly from your book, or press "Skip" to use my own notes.`);
  }

  // STEP 3b — upload + read
  async function onUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setUploadPct(1);
    try {
      const text = await readChapter(file, (p) => setUploadPct(Math.round(p * 100)));
      setChapterText(text);
      await teacherSay(`Got it! I've read your chapter on ${topic}. ✅ Let's begin!`);
      beginTeaching(text);
    } catch {
      await teacherSay("Hmm, I couldn't read that file 😅. Please upload a clear JPG, PNG, or PDF.");
    } finally {
      setBusy(false);
      setUploadPct(0);
    }
  }
  async function skipUpload() {
    await teacherSay("No problem — I'll use my own notes. Let's begin!");
    beginTeaching("");
  }

  // STEP 4 — teach
  async function beginTeaching(text) {
    setStage(STAGE.TEACH);
    setBusy(true);
    const reply = await askTeacher({ chapterText: text, phase: "teach", topic, subject, history: [] });
    setBusy(false);
    await teacherSay(reply);
  }

  // STEP 5 — question
  async function askQuestion() {
    setStage(STAGE.QUIZ);
    setBusy(true);
    const reply = await askTeacher({ chapterText, phase: "quiz", topic, subject, history: hist() });
    setBusy(false);
    setAskedCount((c) => c + 1);
    await teacherSay(reply);
  }

  // STEP 6 — check
  async function submitAnswer(answerText) {
    if (!answerText.trim()) return;
    studentSay(answerText);
    setInput("");
    setBusy(true);
    const reply = await askTeacher({ chapterText, phase: "check", topic, subject, userText: answerText, history: hist() });
    setBusy(false);
    if (/correct|great|well done|exactly|perfect|yes/i.test(reply)) setCorrectCount((c) => c + 1);
    await teacherSay(reply);
  }

  // STEP 7 — homework
  async function giveHomework() {
    setStage(STAGE.HOMEWORK);
    setBusy(true);
    const reply = await askTeacher({ chapterText, phase: "homework", topic, subject, history: hist() });
    setBusy(false);
    await teacherSay(reply);
  }

  async function answerByVoice() {
    const said = await listen();
    if (said) submitAnswer(said);
  }

  return (
    <div className="app">
      <header className="topbar">
        <span className="logo">{SUBJECTS[subject].icon} Ganit Guru</span>
        <span className="subtitle">Class 6 • {subject} • AI Teacher</span>
        <label className="toggle3d">
          <input type="checkbox" checked={use3D} onChange={(e) => setUse3D(e.target.checked)} />
          3D avatar
        </label>
      </header>

      <main className="stage">
        {/* Avatar */}
        <section className="avatar-pane">
          {use3D ? <Avatar3D mouth={mouth} speaking={speaking} /> : <Avatar mouth={mouth} speaking={speaking} />}
          <div className={`status ${speaking ? "on" : ""}`}>
            {speaking ? "Teaching… 🔊" : listening ? "Listening… 🎤" : busy ? "Thinking… 🧠" : "Ready 😊"}
          </div>
          {speaking && <button className="ghost" onClick={stopSpeaking}>Stop voice</button>}
        </section>

        {/* Interaction */}
        <section className="panel">
          {stage === STAGE.WELCOME && (
            <div className="center">
              <h1>Hello! Ready to learn today? 🎉</h1>
              <button className="primary big" onClick={start}>Start Class ▶</button>
            </div>
          )}

          {stage === STAGE.SUBJECT && (
            <div className="center">
              <h2>Choose your subject</h2>
              <div className="topics">
                {Object.keys(SUBJECTS).map((s) => (
                  <button key={s} className="chip big" onClick={() => chooseSubject(s)}>
                    {SUBJECTS[s].icon} {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {stage === STAGE.PICK && (
            <div>
              <h2>Pick today's {subject} topic</h2>
              <div className="topics">
                {SUBJECTS[subject].topics.map((t) => (
                  <button key={t} className="chip" onClick={() => chooseTopic(t)}>{t}</button>
                ))}
              </div>
            </div>
          )}

          {stage === STAGE.UPLOAD && (
            <div className="center">
              <h2>Upload your “{topic}” chapter</h2>
              <label className="upload">
                <input type="file" accept="image/*,application/pdf" onChange={onUpload} hidden />
                📤 Choose JPG / PNG / PDF
              </label>
              {uploadPct > 0 && <div className="bar"><span style={{ width: `${uploadPct}%` }} />{uploadPct}%</div>}
              <button className="ghost" onClick={skipUpload}>Skip — use teacher's notes</button>
            </div>
          )}

          {[STAGE.TEACH, STAGE.QUIZ, STAGE.HOMEWORK].includes(stage) && (
            <div className="chatwrap">
              <div className="chat">
                {messages.map((m, i) => (
                  <div key={i} className={`bubble ${m.role}`}>{m.content}</div>
                ))}
                <div ref={chatEndRef} />
              </div>

              <div className="composer">
                <input
                  value={input}
                  placeholder="Type your answer…"
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && submitAnswer(input)}
                />
                <button className="mic" onClick={answerByVoice} disabled={listening}>🎤</button>
                <button className="primary" onClick={() => submitAnswer(input)}>Send</button>
              </div>

              <div className="controls">
                {stage === STAGE.TEACH && <button className="primary" onClick={askQuestion}>I understood — ask me a question ❓</button>}
                {stage === STAGE.QUIZ && <button className="secondary" onClick={askQuestion}>Next question ➡</button>}
                {stage === STAGE.QUIZ && <button className="primary" onClick={giveHomework}>Finish & give homework 📝</button>}
                {stage === STAGE.HOMEWORK && (
                  <div className="card">
                    📊 Progress ({subject} • {topic}): Attempted {askedCount} • Looked good {correctCount}. Keep practising! 🎉
                  </div>
                )}
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
