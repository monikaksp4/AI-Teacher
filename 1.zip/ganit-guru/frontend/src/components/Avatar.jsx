// Avatar — a friendly, human-like teacher face drawn as SVG.
// The mouth opens/closes based on `mouth` (0..1) driven by the TTS while speaking,
// so it looks like she is really talking. Eyes blink automatically.
import { useEffect, useState } from "react";

export default function Avatar({ mouth = 0, speaking = false }) {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const id = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 140);
    }, 3800);
    return () => clearInterval(id);
  }, []);

  const mouthOpen = 6 + mouth * 26; // px height of mouth
  const eyeH = blink ? 1 : 9;

  return (
    <svg viewBox="0 0 220 260" className="avatar" role="img" aria-label="Teacher avatar">
      {/* subtle glow when speaking */}
      <circle cx="110" cy="120" r="98" fill={speaking ? "#eaf4ff" : "#f3f4f6"} />
      {/* neck + shoulders */}
      <rect x="86" y="176" width="48" height="40" rx="14" fill="#e6b48c" />
      <path d="M40 260 Q110 196 180 260 Z" fill="#4f7cff" />
      {/* hair back */}
      <ellipse cx="110" cy="112" rx="74" ry="80" fill="#3a2b23" />
      {/* face */}
      <ellipse cx="110" cy="120" rx="60" ry="68" fill="#f1c9a5" />
      {/* hair fringe */}
      <path d="M50 96 Q110 34 170 96 Q150 74 110 72 Q70 74 50 96 Z" fill="#3a2b23" />
      {/* eyebrows */}
      <rect x="72" y="98" width="24" height="4" rx="2" fill="#5a4636" />
      <rect x="124" y="98" width="24" height="4" rx="2" fill="#5a4636" />
      {/* eyes */}
      <ellipse cx="84" cy="116" rx="9" ry={eyeH} fill="#ffffff" stroke="#5a4636" />
      <ellipse cx="136" cy="116" rx="9" ry={eyeH} fill="#ffffff" stroke="#5a4636" />
      {!blink && <circle cx="84" cy="116" r="4" fill="#2b2320" />}
      {!blink && <circle cx="136" cy="116" r="4" fill="#2b2320" />}
      {/* nose */}
      <path d="M110 122 L104 140 Q110 144 116 140 Z" fill="#e0a97e" />
      {/* cheeks */}
      <circle cx="74" cy="146" r="7" fill="#f6b3a1" opacity="0.5" />
      <circle cx="146" cy="146" r="7" fill="#f6b3a1" opacity="0.5" />
      {/* mouth (animated) */}
      <ellipse cx="110" cy="162" rx="18" ry={mouthOpen / 2} fill="#7a2e2e" />
      <ellipse cx="110" cy={162 + mouthOpen / 6} rx="10" ry={mouthOpen / 4} fill="#c85a5a" />
      {/* bindi / friendly detail */}
      <circle cx="110" cy="92" r="3" fill="#d64545" />
    </svg>
  );
}
