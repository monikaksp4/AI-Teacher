// Avatar3D — a PHOTOREAL 3D teacher using a Ready Player Me (.glb) model + three.js.
// It lip-syncs by driving the model's ARKit "viseme" blendshapes from the `mouth` value
// (0..1) that the TTS produces while speaking, and blinks automatically.
//
// How to get your own avatar:
//   1. Go to https://readyplayer.me  ->  create a half-body/head avatar.
//   2. Copy the .glb URL and pass it as the `modelUrl` prop (or drop it in /public).
//
// Deps: three  @react-three/fiber  @react-three/drei
import { Suspense, useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { useGLTF, Environment, OrbitControls } from "@react-three/drei";

// A default free RPM sample avatar; replace with your own.
const DEFAULT_MODEL =
  "https://models.readyplayer.me/64bfa15f0e72c63d7c3934a6.glb";

// Map our single "mouth open" value onto several mouth blendshapes for a natural look.
const VISEME_TARGETS = [
  "viseme_aa", "viseme_O", "viseme_E", "mouthOpen", "jawOpen",
];

function Head({ modelUrl, mouthRef, speakingRef }) {
  const { scene } = useGLTF(modelUrl);
  const meshes = useRef([]);
  const blink = useRef({ t: 0, closing: false, value: 0 });

  // Collect all skinned meshes that carry morph targets (face + teeth).
  useEffect(() => {
    const found = [];
    scene.traverse((o) => {
      if (o.isMesh && o.morphTargetDictionary && o.morphTargetInfluences) found.push(o);
    });
    meshes.current = found;
  }, [scene]);

  useFrame((_, dt) => {
    const mouth = mouthRef.current || 0;
    // ---- lip-sync ----
    meshes.current.forEach((m) => {
      const dict = m.morphTargetDictionary;
      VISEME_TARGETS.forEach((name) => {
        const idx = dict[name];
        if (idx !== undefined) {
          // smooth toward target so it doesn't jitter
          const target = speakingRef.current ? mouth : 0;
          m.morphTargetInfluences[idx] +=
            (target - m.morphTargetInfluences[idx]) * Math.min(1, dt * 18);
        }
      });
    });
    // ---- auto blink ----
    const b = blink.current;
    b.t += dt;
    if (b.t > 3.5 && !b.closing) { b.closing = true; b.t = 0; }
    if (b.closing) {
      b.value += dt * 12;
      if (b.value >= 1) b.value = 1;
      if (b.value >= 1 && b.t > 0.12) { b.closing = false; }
    } else {
      b.value = Math.max(0, b.value - dt * 12);
    }
    meshes.current.forEach((m) => {
      ["eyeBlinkLeft", "eyeBlinkRight", "eyesClosed"].forEach((name) => {
        const idx = m.morphTargetDictionary[name];
        if (idx !== undefined) m.morphTargetInfluences[idx] = b.value;
      });
    });
  });

  const model = useMemo(() => {
    scene.position.set(0, -1.55, 0);
    scene.scale.set(1.15, 1.15, 1.15);
    return scene;
  }, [scene]);

  return <primitive object={model} />;
}

export default function Avatar3D({ mouth = 0, speaking = false, modelUrl = DEFAULT_MODEL }) {
  // Refs let useFrame read live values without re-rendering the canvas.
  const mouthRef = useRef(mouth);
  const speakingRef = useRef(speaking);
  mouthRef.current = mouth;
  speakingRef.current = speaking;

  return (
    <div className="avatar3d">
      <Canvas camera={{ position: [0, 0.1, 2.2], fov: 28 }} dpr={[1, 2]}>
        <ambientLight intensity={0.9} />
        <directionalLight position={[2, 3, 3]} intensity={1.1} />
        <Suspense fallback={null}>
          <Head modelUrl={modelUrl} mouthRef={mouthRef} speakingRef={speakingRef} />
          <Environment preset="city" />
        </Suspense>
        {/* Let the child gently rotate the teacher; lock zoom/pan for kids */}
        <OrbitControls enablePan={false} enableZoom={false} minPolarAngle={1.3} maxPolarAngle={1.7} />
      </Canvas>
    </div>
  );
}

useGLTF.preload(DEFAULT_MODEL);
