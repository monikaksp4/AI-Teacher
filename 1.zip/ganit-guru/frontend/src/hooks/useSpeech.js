// useSpeech — voice for the AI teacher, OFFLINE-FIRST.
//
// TTS (speak):
//   • If the backend Piper service is reachable -> use it (fully offline, natural voice).
//   • Otherwise fall back to the browser Web Speech API (speechSynthesis).
//   In BOTH cases we drive the avatar mouth via `onMouth` (real amplitude for Piper
//   audio using WebAudio; a lightweight animation for the browser voice).
//
// STT (listen):
//   • If the backend Whisper service is reachable -> record mic + send WAV for transcription.
//   • Otherwise fall back to the browser SpeechRecognition.
import { useCallback, useEffect, useRef, useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function backendUp(pathname) {
  try {
    const r = await fetch(`${API}${pathname}`, { method: "OPTIONS" });
    return r.ok || r.status === 204 || r.status === 400; // route exists
  } catch {
    return false;
  }
}

export function useSpeech({ onMouth } = {}) {
  const [speaking, setSpeaking] = useState(false);
  const [listening, setListening] = useState(false);
  const audioCtxRef = useRef(null);
  const recognitionRef = useRef(null);
  const mouthTimer = useRef(null);
  const mediaRef = useRef(null);

  // ---------------- TTS ----------------
  const speakOffline = useCallback(
    async (text) => {
      const res = await fetch(`${API}/api/tts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) throw new Error("tts route failed");
      const buf = await res.arrayBuffer();

      const ctx = (audioCtxRef.current ||= new (window.AudioContext || window.webkitAudioContext)());
      const audioBuf = await ctx.decodeAudioData(buf);
      const src = ctx.createBufferSource();
      src.buffer = audioBuf;

      // Real lip-sync: read live amplitude from an analyser -> mouth openness.
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      analyser.connect(ctx.destination);
      const data = new Uint8Array(analyser.frequencyBinCount);

      return new Promise((resolve) => {
        setSpeaking(true);
        const tick = () => {
          if (!src.__playing) return;
          analyser.getByteTimeDomainData(data);
          let sum = 0;
          for (let i = 0; i < data.length; i++) {
            const v = (data[i] - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / data.length); // 0..~0.5
          onMouth && onMouth(Math.min(1, rms * 3.2));
          requestAnimationFrame(tick);
        };
        src.__playing = true;
        src.onended = () => {
          src.__playing = false;
          setSpeaking(false);
          onMouth && onMouth(0);
          resolve();
        };
        src.start();
        tick();
      });
    },
    [onMouth]
  );

  const speakBrowser = useCallback(
    (text) =>
      new Promise((resolve) => {
        if (!("speechSynthesis" in window)) return resolve();
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text.replace(/[*#_`>]/g, ""));
        u.rate = 0.95;
        u.pitch = 1.15;
        const voices = window.speechSynthesis.getVoices();
        u.voice =
          voices.find((v) => /en-IN/i.test(v.lang)) ||
          voices.find((v) => /en-GB|en-US/i.test(v.lang)) ||
          voices[0];
        u.onstart = () => {
          setSpeaking(true);
          mouthTimer.current = setInterval(() => onMouth && onMouth(Math.random() * 0.6 + 0.1), 120);
        };
        const stop = () => {
          setSpeaking(false);
          clearInterval(mouthTimer.current);
          onMouth && onMouth(0);
          resolve();
        };
        u.onend = stop;
        u.onerror = stop;
        window.speechSynthesis.speak(u);
      }),
    [onMouth]
  );

  const speak = useCallback(
    async (text) => {
      try {
        await speakOffline(text); // try Piper first
      } catch {
        await speakBrowser(text); // fall back to browser voice
      }
    },
    [speakOffline, speakBrowser]
  );

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis?.cancel();
    audioCtxRef.current?.suspend?.();
    setSpeaking(false);
    clearInterval(mouthTimer.current);
    onMouth && onMouth(0);
  }, [onMouth]);

  // ---------------- STT ----------------
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) {
      const rec = new SR();
      rec.lang = "en-IN";
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      recognitionRef.current = rec;
    }
  }, []);

  const listenOffline = useCallback(async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const rec = new MediaRecorder(stream, { mimeType: "audio/webm" });
    const chunks = [];
    mediaRef.current = rec;
    setListening(true);

    return new Promise((resolve) => {
      rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        setListening(false);
        const blob = new Blob(chunks, { type: "audio/wav" });
        try {
          const res = await fetch(`${API}/api/stt`, {
            method: "POST",
            headers: { "Content-Type": "audio/wav" },
            body: blob,
          });
          const data = await res.json();
          resolve(data.text || "");
        } catch {
          resolve("");
        }
      };
      rec.start();
      // auto-stop after 6s of speaking
      setTimeout(() => rec.state === "recording" && rec.stop(), 6000);
    });
  }, []);

  const listenBrowser = useCallback(
    () =>
      new Promise((resolve) => {
        const rec = recognitionRef.current;
        if (!rec) return resolve("");
        setListening(true);
        rec.onresult = (e) => { setListening(false); resolve(e.results[0][0].transcript); };
        rec.onerror = () => { setListening(false); resolve(""); };
        rec.onend = () => setListening(false);
        rec.start();
      }),
    []
  );

  const listen = useCallback(async () => {
    if (await backendUp("/api/stt")) {
      try { return await listenOffline(); } catch { /* fall through */ }
    }
    return listenBrowser();
  }, [listenOffline, listenBrowser]);

  const stopListening = useCallback(() => {
    if (mediaRef.current?.state === "recording") mediaRef.current.stop();
  }, []);

  return { speak, stopSpeaking, listen, stopListening, speaking, listening };
}
