// Ganit Guru — Node.js backend ("brain" gateway)
// Runs the AI teacher logic. Works in two modes:
//   1) LOCAL model via Ollama  (set USE_OLLAMA=true)  -> fully offline
//   2) OpenAI-compatible API   (set OPENAI_API_KEY)   -> cloud
// If neither is configured, a built-in RULE-BASED fallback keeps the app usable.

const express = require("express");
const cors = require("cors");
const { buildPersona } = require("./persona");

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

// Offline voice (Piper TTS + whisper.cpp STT). Safe to keep mounted even if the
// binaries aren't installed — those routes just return an error and the frontend
// falls back to the browser's built-in Web Speech API.
try {
  app.use(require("./voice"));
} catch (e) {
  console.warn("Voice module not mounted:", e.message);
}

const USE_OLLAMA = process.env.USE_OLLAMA === "true";
const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434/api/chat";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "llama3.1";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

// ---- Helper: build the message list sent to the model ----
function buildMessages({ chapterText, phase, history, userText, topic, subject }) {
  const phaseHint = {
    teach: `The student wants to learn "${topic}" (${subject}). Teach ONE concept now, briefly, from the chapter. End by asking if they follow.`,
    quiz: `The student finished the topic "${topic}" (${subject}). Ask ONE question to check understanding. Wait for their answer.`,
    check: `Evaluate the student's answer kindly. If correct, praise + ask "why" in one line. If wrong, guide gently and re-ask.`,
    homework: `Generate 4-5 homework problems on "${topic}" (${subject}) from the chapter, plus a 2-line progress note.`,
  }[phase] || "Continue the lesson helpfully.";

  const sys = `${buildPersona(subject)}

CURRENT PHASE: ${phase.toUpperCase()}
INSTRUCTION: ${phaseHint}

CHAPTER CONTENT (teach only from this if present):
"""${(chapterText || "No chapter uploaded. Use standard NCERT Class 6 content.").slice(0, 6000)}"""`;

  const messages = [{ role: "system", content: sys }];
  (history || []).forEach((m) => messages.push({ role: m.role, content: m.content }));
  if (userText) messages.push({ role: "user", content: userText });
  return messages;
}

// ---- Model callers ----
async function callOllama(messages) {
  const res = await fetch(OLLAMA_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: OLLAMA_MODEL, messages, stream: false }),
  });
  const data = await res.json();
  return data.message?.content || "";
}

async function callOpenAI(messages) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({ model: "gpt-4o-mini", messages, temperature: 0.5 }),
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}

// ---- Rule-based fallback so the app always works offline without a model ----
const FALLBACK = {
  Maths: {
    teach: (t) => `Let's learn **${t}**! 😊 Imagine a pizza cut into equal slices — that's how we picture fractions. The top number is how many slices you took; the bottom is the total. \n\nQuick check: if a pizza has 4 equal slices and you eat 1, what fraction did you eat? Are you with me? 🔍`,
    quiz: (t) => `Here's a question on **${t}**: Which is bigger — 1/2 or 1/4? Tell me your reasoning. ⭐`,
    homework: (t) => `📝 **Homework on ${t}**\n1. Write 3 fractions smaller than 1/2.\n2. Compare 2/3 and 3/4.\n3. Add 1/4 + 1/4.\n4. Shade 3/5 of a shape.\n5. You have 8 chocolates, give away 1/4 — how many?\n\n📊 Progress: Good basics. Revise comparing unlike fractions. Great work! 🎉`,
  },
  Science: {
    teach: (t) => `Let's explore **${t}**! 🔬 Look around your kitchen — some foods come from plants (rice, dal) and some from animals (milk, egg). Grouping things helps us understand them. \n\nQuick check: can you name one food that comes from a plant? What do you think, and why? 🔍`,
    quiz: (t) => `Question on **${t}**: Is milk from a plant or an animal source? And give one more example of that type. ⭐`,
    homework: (t) => `📝 **Homework on ${t}**\n1. List 5 plant foods and 5 animal foods.\n2. Which part of the plant do we eat in spinach? In carrot?\n3. Draw one food item and label its source.\n4. Name 2 foods that give us energy.\n5. Write one line: why do we need a balanced diet?\n\n📊 Progress: Curious and observant! Revise food sources. Well done! 🎉`,
  },
  English: {
    teach: (t) => `Let's learn **${t}**! 📖 A noun is a naming word — for a person, place, animal, or thing (like *teacher, Delhi, dog, book*). \n\nQuick check: in the sentence "Riya reads a book", can you spot two nouns? Tell me which and why. 🔍`,
    quiz: (t) => `Question on **${t}**: Find the noun in — "The garden is full of flowers." What type of thing is it naming? ⭐`,
    homework: (t) => `📝 **Homework on ${t}**\n1. Underline the nouns: "My mother bought mangoes from the market."\n2. Write 5 nouns you can see in your room.\n3. Make 3 sentences, each with one noun.\n4. Find 2 place names and 2 person names.\n5. Write one line about your favourite place.\n\n📊 Progress: Good grasp of naming words. Practise spotting nouns in sentences. Great job! 🎉`,
  },
};

function fallbackReply({ phase, topic, subject = "Maths" }) {
  const t = topic || "this topic";
  const bank = FALLBACK[subject] || FALLBACK.Maths;
  if (phase === "check")
    return `Nice effort! Let's verify together. Can you point to the part you're most unsure about? If it's correct, tell me in one line *why* it works. 😊`;
  const fn = bank[phase];
  return fn ? fn(t) : "Let's keep learning! What would you like to do next? 😊";
}

// ---- Main endpoint ----
app.post("/api/teach", async (req, res) => {
  const { chapterText, phase = "teach", history = [], userText = "", topic = "", subject = "Maths" } = req.body;
  try {
    const messages = buildMessages({ chapterText, phase, history, userText, topic, subject });
    let reply = "";
    if (USE_OLLAMA) reply = await callOllama(messages);
    else if (OPENAI_API_KEY) reply = await callOpenAI(messages);
    else reply = fallbackReply({ phase, topic, subject });
    if (!reply) reply = fallbackReply({ phase, topic, subject });
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.json({ reply: fallbackReply({ phase, topic, subject }) });
  }
});

app.get("/", (_, res) => res.send("Ganit Guru backend is running ✅"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🧠 Ganit Guru backend on http://localhost:${PORT}`));
