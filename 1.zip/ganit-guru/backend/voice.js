// voice.js — fully OFFLINE voice service (no cloud):
//   • TTS  via Piper       -> POST /api/tts   { text }        -> audio/wav
//   • STT  via whisper.cpp -> POST /api/stt   (audio blob)    -> { text }
//
// Prerequisites (installed locally, all free & offline):
//   Piper:        https://github.com/rhasspy/piper   (binary + a .onnx voice)
//   whisper.cpp:  https://github.com/ggerganov/whisper.cpp (binary + ggml model)
//
// Set these env vars to point at your local binaries/models:
//   PIPER_BIN=/path/to/piper
//   PIPER_VOICE=/path/to/en_US-amy-medium.onnx
//   WHISPER_BIN=/path/to/whisper.cpp/main
//   WHISPER_MODEL=/path/to/ggml-base.en.bin
//
// Mount this router in server.js:  app.use(require("./voice"));

const express = require("express");
const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const router = express.Router();
router.use(express.raw({ type: "audio/*", limit: "25mb" }));

const PIPER_BIN = process.env.PIPER_BIN || "piper";
const PIPER_VOICE = process.env.PIPER_VOICE || "./voices/en_US-amy-medium.onnx";
const WHISPER_BIN = process.env.WHISPER_BIN || "./whisper/main";
const WHISPER_MODEL = process.env.WHISPER_MODEL || "./whisper/ggml-base.en.bin";

// ---------- TEXT -> SPEECH (Piper) ----------
router.post("/api/tts", express.json(), (req, res) => {
  const text = (req.body?.text || "").replace(/[*#_`>]/g, "").slice(0, 1200);
  if (!text) return res.status(400).json({ error: "No text" });

  const out = path.join(os.tmpdir(), `gg_${Date.now()}.wav`);
  // piper reads text on stdin and writes a wav file
  const piper = spawn(PIPER_BIN, ["--model", PIPER_VOICE, "--output_file", out]);
  piper.stdin.write(text);
  piper.stdin.end();

  piper.on("error", (e) => res.status(500).json({ error: "Piper not found: " + e.message }));
  piper.on("close", (code) => {
    if (code !== 0 || !fs.existsSync(out)) return res.status(500).json({ error: "TTS failed" });
    res.setHeader("Content-Type", "audio/wav");
    fs.createReadStream(out).pipe(res).on("finish", () => fs.unlink(out, () => {}));
  });
});

// ---------- SPEECH -> TEXT (whisper.cpp) ----------
router.post("/api/stt", (req, res) => {
  if (!req.body?.length) return res.status(400).json({ error: "No audio" });
  const inFile = path.join(os.tmpdir(), `gg_${Date.now()}.wav`);
  fs.writeFileSync(inFile, req.body);

  // whisper.cpp: -otxt writes <inFile>.txt with the transcription
  const w = spawn(WHISPER_BIN, ["-m", WHISPER_MODEL, "-f", inFile, "-otxt", "-nt"]);
  w.on("error", (e) => res.status(500).json({ error: "Whisper not found: " + e.message }));
  w.on("close", () => {
    const txtFile = inFile + ".txt";
    let text = "";
    try { text = fs.readFileSync(txtFile, "utf8").trim(); } catch {}
    fs.unlink(inFile, () => {});
    fs.unlink(txtFile, () => {});
    res.json({ text });
  });
});

module.exports = router;
