# 🧮 Ganit Guru — Class 6 Maths Virtual AI Teacher

A **talking, human-like AI teacher** for Class 6 Mathematics that follows this exact flow:

1. 📱 **Student opens the app** → avatar greets them.
2. 🎯 **Avatar asks the subject/topic** to learn today → student selects.
3. 📤 **Student uploads the chapter** (JPG / PNG / PDF) → app reads it (OCR / PDF text).
4. 🧑‍🏫 **Avatar teaches** the topic, one concept at a time, from the uploaded chapter.
5. ❓ **Avatar asks questions** to check understanding.
6. 🔍 **Checks understanding** — re-teaches weak points gently.
7. 📝 **Gives homework** + a progress card.

Everything runs **locally in the browser** (voice, OCR, avatar). The AI "brain" can run
**fully offline** (Ollama), via a **cloud API**, or a built-in **rule-based fallback** so it
always works even with no model configured.

---

## 🗂️ Project structure

```
ganit-guru/
├── backend/                # Node.js "brain" gateway
│   ├── server.js           # /api/teach endpoint (Ollama / OpenAI / fallback)
│   ├── persona.js          # Ganit Guru teaching persona (system prompt)
│   └── package.json
└── frontend/               # ReactJS + Vite app
    ├── index.html
    ├── vite.config.js
    ├── package.json
    └── src/
        ├── App.jsx                 # the 7-step flow
        ├── main.jsx
        ├── styles.css
        ├── components/Avatar.jsx   # SVG talking face (mouth lip-syncs to voice)
        ├── hooks/useSpeech.js      # TTS (speak) + STT (listen), browser Web Speech API
        └── lib/
            ├── readChapter.js      # OCR (tesseract.js) + PDF (pdfjs) reader
            └── api.js              # calls the backend brain
```

---

## ▶️ How to run (local)

### 1) Start the backend (the "brain")
```bash
cd backend
npm install
npm start          # → http://localhost:5000
```
By default it uses the **rule-based fallback** (works with no setup).

**Optional — make it smart:**
- **Fully offline with Ollama:**
  ```bash
  # install Ollama, then:
  ollama pull llama3.1
  USE_OLLAMA=true OLLAMA_MODEL=llama3.1 npm start
  ```
- **Cloud (OpenAI-compatible):**
  ```bash
  OPENAI_API_KEY=sk-xxxx npm start
  ```

### 2) Start the frontend
```bash
cd frontend
npm install
npm run dev        # → http://localhost:5173
```
Open the browser, click **Start Class**, pick a topic, upload a chapter photo/PDF, and learn!

> 💡 Use **Chrome or Edge** for the best Web Speech (voice in/out) support.
> Allow **microphone** access when prompted.

---

## 🧠 How each step maps to the code

| Step | Where |
|------|-------|
| Greet + ask subject | `App.jsx` → `start()` |
| Pick topic | `App.jsx` → `chooseTopic()` |
| Upload + read chapter | `lib/readChapter.js` (OCR + PDF) |
| Teach | backend `phase: "teach"` |
| Ask questions | backend `phase: "quiz"` |
| Check understanding | backend `phase: "check"` |
| Homework + progress | backend `phase: "homework"` |
| Talking face | `components/Avatar.jsx` + `hooks/useSpeech.js` |

---

## 🔧 Make it your own
- **Change the teacher's personality/rules** → edit `backend/persona.js`.
- **Add subjects** (Science, English) → extend `TOPICS` in `App.jsx` and persona.
- **Photoreal avatar** → swap the SVG in `Avatar.jsx` for a **Ready Player Me + three.js**
  model, or an **Azure TTS Avatar** / **D-ID** stream.
- **Better offline voice** → replace Web Speech with **Piper TTS** + **Whisper** (STT).

---

Built for exam prep, one friendly lesson at a time. 🎉
