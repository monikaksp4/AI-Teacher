// Ganit Guru — Node.js backend ("brain" gateway)
// Runs the AI teacher logic. Works in two modes:
//   1) LOCAL model via Ollama  (set USE_OLLAMA=true)  -> fully offline
//   2) OpenAI-compatible API   (set OPENAI_API_KEY)   -> cloud
// If neither is configured, a built-in RULE-BASED fallback keeps the app usable.

const express = require("express");
const cors = require("cors");
const { GANIT_GURU_PERSONA } = require("./persona");

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

const USE_OLLAMA = process.env.USE_OLLAMA === "true";
const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434/api/chat";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "llama3.1";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

// ---- Helper: build the message list sent to the model ----
function buildMessages({ chapterText, phase, history, userText, topic }) {
  const phaseHint = {
    teach: `The student wants to learn "${topic}". Teach ONE concept now, briefly, from the chapter. End by asking if they follow.`,
    quiz: `The student finished the topic "${topic}". Ask ONE question to check understanding. Wait for their answer.`,
    check: `Evaluate the student's answer kindly. If correct, praise + ask "why" in one line. If wrong, guide gently and re-ask.`,
    homework: `Generate 4-5 homework problems on "${topic}" from the chapter, plus a 2-line progress note.`,
  }[phase] || "Continue the lesson helpfully.";

  const sys = `${GANIT_GURU_PERSONA}

CURRENT PHASE: ${phase.toUpperCase()}
INSTRUCTION: ${phaseHint}

CHAPTER CONTENT (teach only from this if present):
"""${(chapterText || "No chapter uploaded. Use standard NCERT Class 6 content.").slice(0, 6000)}"""`;

  const messages = [{ role: "system", content: sys }];
  (history || []).forEach((m) => messages.push({ role: m.role, content: m.content }));
  if (userText) messages.push({ role: "user", content: userText });
  return messages;
}

// ---- Model callers ----
async function callOllama(messages) {
  const res = await fetch(OLLAMA_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: OLLAMA_MODEL, messages, stream: false }),
  });
  const data = await res.json();
  return data.message?.content || "";
}

async function callOpenAI(messages) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({ model: "gpt-4o-mini", messages, temperature: 0.5 }),
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}

// ---- Rule-based fallback so the app always works offline without a model ----
function fallbackReply({ phase, topic, chapterText }) {
  const t = topic || "this topic";
  switch (phase) {
    case "teach":
      return `Let's learn **${t}**! 😊 Imagine you have a pizza cut into equal slices — that's how we picture fractions. A fraction has a top number (how many slices you took) and a bottom number (total slices). \n\nQuick check: if a pizza has 4 equal slices and you eat 1, what fraction did you eat? Are you with me so far? 🔍`;
    case "quiz":
      return `Great! Here's a question on **${t}**: \n\nWhich is bigger — 1/2 or 1/4? Take your time and tell me your reasoning. ⭐`;
    case "check":
      return `Nice effort! Let's verify together. Can you point to the step you're most unsure about? If it's correct, tell me in one line *why* your answer works. 😊`;
    case "homework":
      return `📝 **Homework on ${t}**\n1. Write 3 fractions smaller than 1/2.\n2. Compare 2/3 and 3/4 — which is bigger?\n3. Add 1/4 + 1/4.\n4. Draw a shape and shade 3/5 of it.\n5. One word problem: You have 8 chocolates and give away 1/4. How many did you give?\n\n📊 Progress: Good understanding of basics. Revise comparing unlike fractions. You did great today! 🎉`;
    default:
      return "Let's keep learning! What would you like to do next? 😊";
  }
}

// ---- Main endpoint ----
app.post("/api/teach", async (req, res) => {
  const { chapterText, phase = "teach", history = [], userText = "", topic = "" } = req.body;
  try {
    const messages = buildMessages({ chapterText, phase, history, userText, topic });
    let reply = "";
    if (USE_OLLAMA) reply = await callOllama(messages);
    else if (OPENAI_API_KEY) reply = await callOpenAI(messages);
    else reply = fallbackReply({ phase, topic, chapterText });
    if (!reply) reply = fallbackReply({ phase, topic, chapterText });
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.json({ reply: fallbackReply({ phase, topic, chapterText }) });
  }
});

app.get("/", (_, res) => res.send("Ganit Guru backend is running ✅"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🧠 Ganit Guru backend on http://localhost:${PORT}`));
