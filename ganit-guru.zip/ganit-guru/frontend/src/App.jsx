// Ganit Guru — Class 6 Math AI Teacher (main app)
// Implements the exact 7-step flow:
//   1. Open app  -> avatar greets
//   2. Avatar asks the subject/topic to learn
//   3. Student selects topic + uploads chapter (JPG/PDF)  -> OCR/PDF read
//   4. Avatar teaches the topic
//   5. Avatar asks questions
//   6. Checks understanding (re-teaches weak points)
//   7. Gives homework + progress card
import { useEffect, useRef, useState } from "react";
import Avatar from "./components/Avatar";
import { useSpeech } from "./hooks/useSpeech";
import { readChapter } from "./lib/readChapter";
import { askTeacher } from "./lib/api";
import "./styles.css";

const TOPICS = [
  "Knowing Our Numbers", "Whole Numbers", "Playing with Numbers",
  "Basic Geometrical Ideas", "Integers", "Fractions",
  "Decimals", "Data Handling", "Mensuration", "Algebra", "Ratio and Proportion",
];

// App stages
const STAGE = {
  WELCOME: "welcome",
  PICK: "pick",
  UPLOAD: "upload",
  TEACH: "teach",
  QUIZ: "quiz",
  HOMEWORK: "homework",
};

export default function App() {
  const [stage, setStage] = useState(STAGE.WELCOME);
  const [topic, setTopic] = useState("");
  const [chapterText, setChapterText] = useState("");
  const [uploadPct, setUploadPct] = useState(0);
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState([]); // {role, content}
  const [input, setInput] = useState("");
  const [mouth, setMouth] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [askedCount, setAskedCount] = useState(0);
  const chatEndRef = useRef(null);

  const { speak, stopSpeaking, listen, speaking, listening } = useSpeech({ onMouth: setMouth });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Make the avatar say something and add it to the transcript
  async function teacherSay(text) {
    setMessages((m) => [...m, { role: "assistant", content: text }]);
    await speak(text);
  }
  function studentSay(text) {
    setMessages((m) => [...m, { role: "user", content: text }]);
  }

  // ---- STEP 1 & 2: greet + ask subject ----
  async function start() {
    setStage(STAGE.PICK);
    await teacherSay(
      "Namaste! 🙏 I'm Ganit Guru, your Class 6 maths teacher. Which topic shall we learn today? Pick one below, or tell me."
    );
  }

  // ---- STEP 3a: pick topic ----
  async function chooseTopic(t) {
    setTopic(t);
    setStage(STAGE.UPLOAD);
    await teacherSay(
      `Great choice — ${t}! 😊 Please upload your chapter as a JPG, PNG, or PDF so I teach exactly from your book. Or press "Skip" to use my own notes.`
    );
  }

  // ---- STEP 3b: upload + read chapter ----
  async function onUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setUploadPct(1);
    try {
      const text = await readChapter(file, (p) => setUploadPct(Math.round(p * 100)));
      setChapterText(text);
      await teacherSay(`Got it! I've read your chapter on ${topic}. ✅ Let's begin!`);
      beginTeaching(text);
    } catch (err) {
      await teacherSay("Hmm, I couldn't read that file 😅. Please upload a clear JPG, PNG, or PDF.");
    } finally {
      setBusy(false);
      setUploadPct(0);
    }
  }

  async function skipUpload() {
    await teacherSay("No problem — I'll use my own notes. Let's begin!");
    beginTeaching("");
  }

  // ---- STEP 4: teach ----
  async function beginTeaching(text) {
    setStage(STAGE.TEACH);
    setBusy(true);
    const reply = await askTeacher({ chapterText: text, phase: "teach", topic, history: [] });
    setBusy(false);
    await teacherSay(reply);
  }

  // ---- STEP 5: ask a question ----
  async function askQuestion() {
    setStage(STAGE.QUIZ);
    setBusy(true);
    const reply = await askTeacher({
      chapterText, phase: "quiz", topic,
      history: messages.map(({ role, content }) => ({ role, content })),
    });
    setBusy(false);
    setAskedCount((c) => c + 1);
    await teacherSay(reply);
  }

  // ---- STEP 6: student answers -> check understanding ----
  async function submitAnswer(answerText) {
    if (!answerText.trim()) return;
    studentSay(answerText);
    setInput("");
    setBusy(true);
    const reply = await askTeacher({
      chapterText, phase: "check", topic, userText: answerText,
      history: messages.map(({ role, content }) => ({ role, content })),
    });
    setBusy(false);
    // light heuristic for the progress card
    if (/correct|great|well done|exactly|perfect|yes/i.test(reply)) setCorrectCount((c) => c + 1);
    await teacherSay(reply);
  }

  // ---- STEP 7: homework ----
  async function giveHomework() {
    setStage(STAGE.HOMEWORK);
    setBusy(true);
    const reply = await askTeacher({
      chapterText, phase: "homework", topic,
      history: messages.map(({ role, content }) => ({ role, content })),
    });
    setBusy(false);
    await teacherSay(reply);
  }

  // Voice answer via mic
  async function answerByVoice() {
    const said = await listen();
    if (said) submitAnswer(said);
  }

  return (
    <div className="app">
      <header className="topbar">
        <span className="logo">🧮 Ganit Guru</span>
        <span className="subtitle">Class 6 Maths • AI Teacher</span>
      </header>

      <main className="stage">
        {/* ---- Left: talking avatar ---- */}
        <section className="avatar-pane">
          <Avatar mouth={mouth} speaking={speaking} />
          <div className={`status ${speaking ? "on" : ""}`}>
            {speaking ? "Teaching… 🔊" : listening ? "Listening… 🎤" : busy ? "Thinking… 🧠" : "Ready 😊"}
          </div>
          {speaking && <button className="ghost" onClick={stopSpeaking}>Stop voice</button>}
        </section>

        {/* ---- Right: interaction ---- */}
        <section className="panel">
          {stage === STAGE.WELCOME && (
            <div className="center">
              <h1>Hello! Ready to learn maths? 🎉</h1>
              <button className="primary big" onClick={start}>Start Class ▶</button>
            </div>
          )}

          {stage === STAGE.PICK && (
            <div>
              <h2>Pick today's topic</h2>
              <div className="topics">
                {TOPICS.map((t) => (
                  <button key={t} className="chip" onClick={() => chooseTopic(t)}>{t}</button>
                ))}
              </div>
            </div>
          )}

          {stage === STAGE.UPLOAD && (
            <div className="center">
              <h2>Upload your “{topic}” chapter</h2>
              <label className="upload">
                <input type="file" accept="image/*,application/pdf" onChange={onUpload} hidden />
                📤 Choose JPG / PNG / PDF
              </label>
              {uploadPct > 0 && <div className="bar"><span style={{ width: `${uploadPct}%` }} />{uploadPct}%</div>}
              <button className="ghost" onClick={skipUpload}>Skip — use teacher's notes</button>
            </div>
          )}

          {[STAGE.TEACH, STAGE.QUIZ, STAGE.HOMEWORK].includes(stage) && (
            <div className="chatwrap">
              <div className="chat">
                {messages.map((m, i) => (
                  <div key={i} className={`bubble ${m.role}`}>{m.content}</div>
                ))}
                <div ref={chatEndRef} />
              </div>

              {/* Answer box */}
              <div className="composer">
                <input
                  value={input}
                  placeholder="Type your answer…"
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && submitAnswer(input)}
                />
                <button className="mic" onClick={answerByVoice} disabled={listening}>🎤</button>
                <button className="primary" onClick={() => submitAnswer(input)}>Send</button>
              </div>

              {/* Teacher controls for the flow */}
              <div className="controls">
                {stage === STAGE.TEACH && <button className="primary" onClick={askQuestion}>I understood — ask me a question ❓</button>}
                {stage === STAGE.QUIZ && <button className="secondary" onClick={askQuestion}>Next question ➡</button>}
                {stage === STAGE.QUIZ && <button className="primary" onClick={giveHomework}>Finish & give homework 📝</button>}
                {stage === STAGE.HOMEWORK && (
                  <div className="card">
                    📊 Progress: Attempted {askedCount} • Looked good {correctCount}. Keep practising! 🎉
                  </div>
                )}
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
