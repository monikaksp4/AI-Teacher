// useSpeech — browser Text-to-Speech (speak) + Speech-to-Text (listen)
// Fully local, no cloud. Uses the Web Speech API built into modern browsers.
import { useCallback, useEffect, useRef, useState } from "react";

export function useSpeech({ onMouth } = {}) {
  const [speaking, setSpeaking] = useState(false);
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);
  const mouthTimer = useRef(null);

  // ---- SPEAK (TTS) + drive avatar mouth ----
  const speak = useCallback(
    (text) =>
      new Promise((resolve) => {
        if (!("speechSynthesis" in window)) return resolve();
        window.speechSynthesis.cancel();
        const clean = text.replace(/[*#_`>]/g, ""); // strip markdown for speech
        const u = new SpeechSynthesisUtterance(clean);
        u.rate = 0.95;
        u.pitch = 1.15;
        // Prefer an Indian English female voice if available
        const voices = window.speechSynthesis.getVoices();
        u.voice =
          voices.find((v) => /en-IN/i.test(v.lang) && /female|zira|neerja/i.test(v.name)) ||
          voices.find((v) => /en-IN/i.test(v.lang)) ||
          voices.find((v) => /en-GB|en-US/i.test(v.lang)) ||
          voices[0];

        u.onstart = () => {
          setSpeaking(true);
          // animate mouth open/close while speaking
          mouthTimer.current = setInterval(() => {
            onMouth && onMouth(Math.random() * 0.6 + 0.1);
          }, 120);
        };
        const stop = () => {
          setSpeaking(false);
          clearInterval(mouthTimer.current);
          onMouth && onMouth(0);
          resolve();
        };
        u.onend = stop;
        u.onerror = stop;
        window.speechSynthesis.speak(u);
      }),
    [onMouth]
  );

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
    clearInterval(mouthTimer.current);
    onMouth && onMouth(0);
  }, [onMouth]);

  // ---- LISTEN (STT) ----
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    const rec = new SR();
    rec.lang = "en-IN";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    recognitionRef.current = rec;
  }, []);

  const listen = useCallback(
    () =>
      new Promise((resolve) => {
        const rec = recognitionRef.current;
        if (!rec) return resolve("");
        setListening(true);
        rec.onresult = (e) => {
          const said = e.results[0][0].transcript;
          setListening(false);
          resolve(said);
        };
        rec.onerror = () => {
          setListening(false);
          resolve("");
        };
        rec.onend = () => setListening(false);
        rec.start();
      }),
    []
  );

  return { speak, stopSpeaking, listen, speaking, listening };
}
